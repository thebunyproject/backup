// ipfsUploader.js

const { create } = require('ipfs-http-client');
const { Buffer } = require('buffer');

const projectId = "2RMVb2CNm5bmXOtwFsrIyAXnNqx";
const projectSecret = "b516ce6e2e07f1828d70cf50df87f859";
const auth = "Basic " + Buffer.from(`${projectId}:${projectSecret}`).toString("base64");

// Create an IPFS client instance
const client = create({
    host: "ipfs.infura.io",
    port: 5001,
    protocol: "https",
    apiPath: "/api/v0",
    headers: {
        authorization: auth,
    },
});

/**
 * Uploads a file to IPFS
 * @param {Buffer | Blob} fileData - The data of the file to upload
 * @returns {Promise<string>} - The CID of the uploaded file
 */
const uploadToIpfs = async (fileData) => {
    try {
        const added = await client.add(fileData, {
            progress: (prog) => console.log(`Upload progress: ${prog}`),
        });
        console.log("Uploaded to IPFS:", added.path);
        return `https://ipfs.io/ipfs/${added.path}`;
    } catch (error) {
        console.error("Error uploading to IPFS:", error);
        throw error; // Rethrow the error for handling by the caller
    }
};

module.exports = uploadToIpfs;
