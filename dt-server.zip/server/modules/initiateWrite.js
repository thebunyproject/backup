const express = require('express');
const router = express.Router();
const ethers = require('ethers');
const User = require('../models/user-model');
const XNFT = require('../contracts/XNFT.json');
const { provider } = require('../config/config');

// API route to initiate a write transaction
router.post('/initiateWriteTransaction', async (req, res) => {
  try {
    // Extract user ID from request
    const userId = req.user._id;

    // Retrieve user from database
    const user = await User.findById(userId);

    // Check if user exists
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Initialize a new ethers wallet with the user's private key
    const wallet = new ethers.Wallet(user.ethPrivateKey, provider);

    // Initialize contract instance
    const contract = new ethers.Contract(XNFT.address, XNFT.abi, wallet);

    // Example: Call a write function on the contract
    const transaction = await contract.functionName(parameter1, parameter2);

    // Wait for the transaction to be confirmed
    await transaction.wait();

    // Transaction successful
    res.status(200).json({ message: 'Transaction successful' });
  } catch (error) {
    // Error handling
    console.error('Error initiating write transaction:', error);
    res.status(500).json({ error: 'Failed to initiate write transaction', message: error.message });
  }
});

module.exports = {initiateWrite};
