const ethers = require("ethers");
const XNFT = require("../contracts/XNFT.json");
const Registry = require("../contracts/Registry.json");
//const Account = require("../../contracts/Account.json");
const { wallet } = require("../config/config");
const contractABI = XNFT.abi;
const contractAddress = XNFT.address;
const registryContractAddress = Registry.address;

/**
 * Call the `callCreateAccount` function on a smart contract.
 *
 * @param {string} providerUrl - URL of the Ethereum node.
 * @param {string} privateKey - Private key of the wallet to use for the transaction.
 * @param {string} contractAddress - Address of the smart contract.
 * @param {Array} contractABI - ABI of the smart contract.
 * @param {string} registryContractAddress - Address of the registry contract.
 * @param {string} tokenId - Token ID as a string.
 * @param {string} signature - The signature as a hex string.
 * @returns {Promise<string>} The transaction hash of the call.
 */
async function callCreateAccount(tokenId, signature) {
  const contract = new ethers.Contract(contractAddress, contractABI, wallet);
  const imp = await contract.implementation();
  console.log(imp);
  // Call the smart contract function
  try {
    const txResponse = await contract.callCreateAccount(
      registryContractAddress,
      tokenId,
      signature,
    );
    await txResponse.wait(); // Wait for the transaction to be mined
    const transactionHash = txResponse.hash; // Get the transaction hash
    console.log("Transaction mined:", transactionHash);
    return transactionHash; // Return the transaction hash
  } catch (error) {
    console.error("Failed to call createAccount:", error);
    throw error;
  }
}

module.exports = { callCreateAccount };
