const { create } = require('ipfs-http-client');
const fs = require('fs');

// Configure your IPFS client
const projectId = "2RMVb2CNm5bmXOtwFsrIyAXnNqx";
const projectSecret = "b516ce6e2e07f1828d70cf50df87f859";
const auth = "Basic " + Buffer.from(`${projectId}:${projectSecret}`).toString("base64");

const client = create({
  host: "ipfs.infura.io",
  port: 5001,
  protocol: "https",
  headers: {
    authorization: auth,
  },
});

/**
 * Uploads JSON metadata to IPFS.
 * @param {Object} metadata - The metadata object to upload.
 * @returns {Promise<string>} - The CID of the uploaded metadata.
 */
async function uploadMetadataToIpfs(metadata) {
    try {
        const metadataStr = JSON.stringify(metadata, null, 2); // Convert metadata object to string
        const added = await client.add(metadataStr); // Upload metadata string to IPFS
        console.log(`Metadata uploaded to IPFS: ${added.path}`);
        return `https://ipfs.io/ipfs/${added.path}`; // Return the full URL
    } catch (error) {
        console.error(`Error uploading metadata to IPFS: ${error}`);
        throw error; // Rethrow the error for handling by the caller
    }
}

module.exports = {uploadMetadataToIpfs};
