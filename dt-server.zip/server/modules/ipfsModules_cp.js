const fs = require('fs');
const ipfsClient = require('ipfs-http-client');
const all = require('it-all');
const path = require('path');
const uint8ArrayConcat = require('uint8arrays/concat');
const uint8ArrayToString = require('uint8arrays/to-string');

const projectId = "2RMVb2CNm5bmXOtwFsrIyAXnNqx";
const projectSecret = "b516ce6e2e07f1828d70cf50df87f859";
const auth = "Basic " + Buffer.from(`${projectId}:${projectSecret}`).toString("base64");

// Initialize IPFS client
const ipfs = ipfsClient({ host: 'ipfs.infura.io', port: 5001, protocol: 'https',  headers: {
    authorization: auth,
}, });

/**
 * Upload a file to IPFS.
 * 
 * @param {string} filePath - The path to the file to be uploaded.
 * @returns {Promise<string>} The CID of the uploaded file.
 */
async function uploadFile(content) {
    if (typeof content === 'string') {
        // Convert string to Buffer if it is not already a Buffer
        content = Buffer.from(content);
    }
    const fileAdded = await ipfs.add(content);
    const cid = fileAdded.cid.toString();
    console.log(`Content uploaded to IPFS with CID: ${cid}`);
    return cid;
}

/**
 * Fetches and prints file content from IPFS by CID.
 * 
 * @param {string} cid - The CID of the file to fetch.
 */
async function fetchFileContent(cid) {
    const content = uint8ArrayConcat(await all(ipfs.cat(cid)));
    const contentString = uint8ArrayToString(content);
    console.log(`Content for CID ${cid}:`, contentString);
    return contentString;
}

/**
 * Save file content from IPFS by CID to local file system.
 * 
 * @param {string} cid - The CID of the file to save.
 * @param {string} savePath - The path where to save the file.
 */
async function saveFileFromIpfs(cid, savePath) {
    const data = uint8ArrayConcat(await all(ipfs.cat(cid)));
    const strData = uint8ArrayToString(data);
    fs.writeFileSync(savePath, strData);
    console.log(`Data from CID ${cid} saved to ${savePath}`);
}

module.exports = { uploadFile, fetchFileContent, saveFileFromIpfs };
