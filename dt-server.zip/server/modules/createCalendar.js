const ethers = require("ethers");
const User = require('../models/user-model');
const CalendarFactory = require('../contracts/CalendarFactory.json');
const { provider } = require('../config/config');

const createCalendar = async (
  req,
  inputName,
  inputVisibility
) => {
  try {
    // Retrieve user from request
    const user = req.user;

    // Check if user exists
    if (!user) {
      console.error('User not found');
      return;
    }

    // Initialize signer with user's private key
    const signer = new ethers.Wallet(user.privateKey, provider);

    const contractAddress = CalendarFactory.address;
    const contractABI = CalendarFactory.abi;

    const contract = new ethers.Contract(
      contractAddress,
      contractABI,
      signer
    );

    // Event listener setup
    const calendarCreatedListener = (
      calendarSender,
      calendarAddress,
      calendarName,
      visibility,
      event
    ) => {
      console.log("Calendar Created:", {
        calendarSender,
        calendarAddress,
        calendarName,
        visibility,
      });
      // Handle event as needed
      contract.off("CalendarCreated", calendarCreatedListener);
    };

    contract.on("CalendarCreated", calendarCreatedListener);

    const transaction = await contract.createTelosCalendar(
      inputName,
      inputVisibility
    );
    const receipt = await transaction.wait();

    if (receipt.status !== 1) {
      console.error("Transaction failed");
      return;
    }

    console.log("Transaction receipt:", receipt);
    // Handle transaction receipt as needed

    // Example deployLogLink
    const deployLogLink = `https://testnet.teloscan.io/tx/${transaction.hash}`;
    console.log(deployLogLink);

    // Example success notification
    console.log("Transaction Successful");

    // Example recent transaction addition
    console.log("Recent transaction added:", {
      hash: transaction.hash,
      description: "Calendar Created",
    });
  } catch (error) {
    console.error("Error creating calendar:", error);
    // Handle error as needed
    console.log("Transaction Failed");
  }
};

module.exports = { createCalendar };
