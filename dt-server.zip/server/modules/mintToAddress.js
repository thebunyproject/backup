const ethers = require("ethers");
const XNFT = require("../contracts/XNFT.json");
const { wallet } = require("../config/config"); // Adjust according to your config structure

async function mintToAddress(mintParams) {
  const { tokenId, cid, receiver } =
    mintParams;

  const contract = new ethers.Contract(XNFT.address, XNFT.abi, wallet);

  // Execute the mintToAddress function on your contract
  
  const tx = await contract.mintToAddress(
    tokenId,
    cid,
    receiver
  );

  // Wait for the transaction to be mined
  await tx.wait();

  console.log(`Minting successful! Transaction hash: ${tx.hash}`);
  return tx.hash;
}

module.exports = { mintToAddress };
