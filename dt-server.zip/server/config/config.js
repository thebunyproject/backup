require("dotenv").config();
const ethers = require("ethers");

exports.PORT = 4001;
// Avalanche mainnet RPC url
exports.providerUrl = 'https://testnet.telos.net/evm';
// provider
exports.provider = new ethers.providers.JsonRpcProvider(
    exports.providerUrl,
  );

exports.mnemonic = process.env.MNEMONIC;

// wallet
exports.wallet = ethers.Wallet.fromMnemonic(exports.mnemonic).connect(exports.provider);

