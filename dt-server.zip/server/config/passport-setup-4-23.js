const passport = require("passport");
const TwitterStrategy = require("passport-twitter");
const keys = require("./keys");
const XNFT = require("../contracts/XNFT.json");
const ethers = require("ethers");
const User = require("../models/user-model");
const EthCrypto = require("eth-crypto");
const { mintToAddress } = require("../modules/mintToAddress");
const {
  uploadFile,
} = require("../modules/ipfsModule");

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  User.findById(id)
    .then((user) => {
      done(null, user);
    })
    .catch((e) => {
      done(new Error("Failed to deserialize an user"));
    });
});

async function ipfsMain(metadata) {
  try {
    // Convert the metadata object to a JSON string, then to a Buffer
    const metadataBuffer = Buffer.from(JSON.stringify(metadata));
    const metadataUrl = await uploadFile(metadataBuffer);
    console.log(`Metadata URL: ${metadataUrl}`);
    return metadataUrl;
  } catch (error) {
    console.error(`Failed to upload metadata: ${error}`);
    throw error;
  }
}


passport.use(
  new TwitterStrategy(
    {
      consumerKey: keys.TWITTER_CONSUMER_KEY,
      consumerSecret: keys.TWITTER_CONSUMER_SECRET,
      callbackURL: "http://localhost:4001/auth/twitter/redirect",
    },
    async (token, tokenSecret, profile, done) => {
      // Find current user in UserModel
      const currentUser = await User.findOne({
        twitterId: profile._json.id_str,
      });
      console.log(currentUser);
      // Suppose metadataUrl is obtained or generated here
      const metadata = {
        name: profile._json.name,
        description: "Daily Telos X NFT",
        image: profile._json.profile_image_url,
      };

      let metadataUrl = await ipfsMain(metadata);
      console.log(`Metadata URL: ${metadataUrl}`);

      // Create new user if the database doesn't have this user
      if (!currentUser) {

        // create eth identity
        const identity = EthCrypto.createIdentity();

        // Create new user in database
        const newUser = await new User({
          name: profile._json.name,
          screenName: profile._json.screen_name,
          twitterId: profile._json.id_str,
          profileImageUrl: profile._json.profile_image_url,
          ethAddress: identity.address,
          ethPrivateKey: identity.privateKey,
          metadata: metadataUrl
        }).save();

        // mint X-NFT for new user
        if (newUser) {

          const mintParams = {
            tokenId: newUser.twitterId, // Make sure this matches your contract's expectations
            cid: metadataUrl,
            receiver: newUser.ethAddress,
          };

          let txHash = "";


          try {
            txHash = await mintToAddress(mintParams);
            console.log(`Minting successful! Transaction hash: ${txHash}`);

            // Update the newUser document with NFT details
            await User.findByIdAndUpdate(newUser._id, {
              chainId: chainId,
              nftTokenId: mintParams.tokenId,
              nftContractAddress: XNFT.address,
              nftTxHash: txHash,
            });
            console.log("NFT details saved to database.");

            done(null, newUser);
          } catch (error) {
            console.error("Minting failed:", error);
          }

          done(null, newUser);
        }
      } else {
        done(null, currentUser);
      }
    },
  ),
);
