const TWITTER_TOKENS = {
  TWITTER_CONSUMER_SECRET: 'YXrOggmDvYffahg7rnqUnDl5jj5DUSRTXQI7zcppP7H4upsfdC',
TWITTER_CONSUMER_KEY: 'GSAembEtvxOFTRq6tYwTrPYQ2',
TWITTER_ACCESS_TOKEN: "1483171886452383745-djEL3hLZMVus7GMbEqP107937WMCCb",
TWITTER_TOKEN_SECRET: "MgrB8nsQzGy9BNeHCDsfmAgGJaEI4rkrOcrhFs9lTW0MG",
BEARER_TOKEN: "AAAAAAAAAAAAAAAAAAAAANT6sQEAAAAARSMqCp9B11paX%2FMap9yypBRnyvQ%3DcAeFp5MO9DeiiMMSMkshchB1nbRUgvKKAv5nkQrOPXDl8uYzQX"
};

const MONGODB = {
  MONGODB_URI: `mongodb+srv://rob4102:8d!HCAZaqgLZj7h@cluster0.bib3mki.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`
};

const SESSION = {
  COOKIE_KEY: "thisappisawesome"
};

const KEYS = {
  ...TWITTER_TOKENS,
  ...MONGODB,
  ...SESSION
};

module.exports = KEYS;
