// google-passport-auth.js
const passport = require("passport");
const GoogleStrategy = require("passport-google-oauth20").Strategy;
const keys = require("./keys");
const User = require("../models/user-model");

passport.use(
  new GoogleStrategy(
    {
      clientID: keys.GOOGLE_CLIENT_ID,
      clientSecret: keys.GOOGLE_CLIENT_SECRET,
      callbackURL: "/auth/google/redirect"
    },
    async (accessToken, refreshToken, profile, done) => {
      // find current user in UserModel
      const currentUser = await User.findOne({ googleId: profile.id });
      
      // create new user if the database doesn't have this user
      if (!currentUser) {
        const newUser = await new User({
          username: profile.displayName,
          googleId: profile.id,
          // Add any other fields you want to save from Google profile
        }).save();
        
        if (newUser) {
          done(null, newUser);
        }
      }
      
      done(null, currentUser);
    }
  )
);

module.exports = passport;
